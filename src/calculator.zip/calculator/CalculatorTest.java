package calculator;

import org.junit.Test;
import static org.junit.Assert.*;

public class CalculatorTest {

	@Test
	public void test() {
		MultiUnitCalculator calculator;
		calculator = new MultiUnitCalculator();
		assertEquals("5.4 in", calculator.evaluate("(3 + 2.4)in"));
		assertEquals("48.0", calculator.evaluate("12pts*4in"));		
		assertEquals("7.0", calculator.evaluate("(3 + 4)"));
		assertEquals("18.0",calculator.evaluate("3+2.2+12.8"));
		assertEquals("5.1",calculator.evaluate("3+2.1"));
		assertEquals("1.1",calculator.evaluate("4.4/4"));
		assertEquals("4.3", calculator.evaluate("3+2.4-1.1"));
		
		
		
	}
	

}