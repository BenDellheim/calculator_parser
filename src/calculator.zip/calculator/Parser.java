package calculator;


import calculator.Lexer.Token;
import java.util.ArrayList;

/* Requirements:
 * "Your parser should use the tokenization produced by
 * the Lexer to parse the expression according to the
 * grammar defined in Problem 1. Exactly how you do
 * this is up to you; the only thing that we enforce is
 * that the Lexer is passed as an argument to the Parser constructor.
 * b. Write test cases for these methods in a separate file.
 * c. Implement the Parser and make sure all your tests pass."
 */

/* Valid inputs:
 * Expression ::= number | number unit | operand
 * Number ::= scalar | unit
 * Scalar ::= whole | decimal
 * Operand ::= + | - | * | /
 * Unit ::= inches | points
 */


/* Class Parser - our Calculator parser. All values are measured in Points.
 * evaluate(String) - Main public function that calls all the parser routines.
 *                    It returns a Value, so be sure to import Parser.Value. 
 * 
 * Subclasses: Value, Expression
 */
class Parser {

    Lexer lexer; // Takes the input string and creates tokens through lexer.next().
    int stack;   // Counts how many parentheses we're inside. Default 0. (255 parentheses should be enough for everybody.)
    private static final double PT_PER_IN = 72;

	@SuppressWarnings("serial")
	static class ParserException extends RuntimeException {
	}

	/* Constructor.
	 * Parser instances start with a Lexer, which tokenizes the input stream for us.
	 * Marvelous! How convenient!
	 */
    Parser (Lexer lex)
    {
        this.lexer = lex;
        stack = 0;

    }

	/* Class Expression covers 2 kinds of expressions:
	 * One with a single parameter (leaf) with no operator, and
	 * one with 3 parameters (operator, leftExpression, rightExpression)
	 *  i.e. (PLUS, ex1, ex2) -> ex1 PLUS ex2.
	 */
    public class Expression {

        Token leaf;

        Expression leftExpression;
        Token operator;
        Expression rightExpression;

        public Expression(Token leaf) {
            this.leaf = leaf;
        }

        public Expression(Token operator, Expression leftExpression, Expression rightExpression) {
        	this.leaf = null;
            this.operator = operator;
            this.leftExpression = leftExpression;
            this.rightExpression = rightExpression;
        }

        public Boolean isLeaf() {
            return this.leaf != null;
        }
    }

    /* Class Value pairs a (double) with the enum ValueType (INCHES, POINTS, SCALAR)
     * and overrides toString() to display it properly.
     */
	public class Value {
		final double value;
		final ValueType type;

		Value(double value, ValueType type) {
			this.value = value;
			this.type = type;
		}

		@Override
		public String toString() {
			switch (type) {
			case INCHES:
				// Internal value is always in points.
				// return value / PT_PER_IN + " in";
				// No it's not. Douche.
				return value + " in";
			case POINTS:
				return value + " pt";
			default:
				return "" + value;
			}
		}
	}

	/* Parse() - not to be confused with the constructor
	 * This takes a tokenized Lexer and converts it to an Expression.
	 * Expressions can contain smaller Expressions, or a singular value (leaf).
	 * */
    public Expression Parse(Lexer lexer) {

        /*******************************************************
         * Parse() is supposed to recursively create an Expression,
         * by iterating through the passed Lexer object with Lexer.next().
         * (BTW: next() checks if the string is used up and returns null,
         *  so this code needs to check for a null return.)
         *******************************************************/

        /* Tokens contain a Type, and either a String of text or (null).
         * They can return their value (Double), their Type (i.e MULTIPLY),
         *  or their ValueType (i.e SCALAR).*/

        Expression leftExpression = null;
        Expression tempExpression = null;
        Token operator = null;
        Token token = lexer.next();
        
        // STEP 1 (Priming the loop): Read a # or LPAREN
        if( token != null && token.isNumber())
        {
    		System.out.println("In Step 1': Number (" + token.getTokenValue() + token.getTokenType() + ")");
        	// Make the # a new leaf expression.
        	leftExpression = new Expression(token);

        	// If we're inside () [stack > 0] it's safe to return the leaf
           	//  without exiting the rest of the parse tree.
           	if( stack > 0)
           	{
           		stack--;
           		return leftExpression;
           	}
           	token = lexer.next();
   			// Otherwise continue: Since this is the prime,
   			// the Number is stored directly in leftExpression.
        }
        else if( token != null && token.getOperatorType() == Type.OPENPAREN)
        {
    		System.out.println("In Step 1': (");
        	// Recurse to evaluate inside of "("
        	stack++;
        	leftExpression = Parse(lexer);
        	token = lexer.next();
        }

        // Main loop
        while(token != null)
        {
        	// STEP 2: Read operator (+-*/) or RPAREN
        	// If operator, add it to the current expression and self-call to further evaluate
        	// If ")", return the current expression if inside a "(" [stack > 0]
        	if( token.isOperator())
        	{
        		System.out.println("In Step 2: Operator (" + token.text + ")");
        		operator = token;
        		stack++;
        		if( leftExpression != null){
        			leftExpression = new Expression( operator, leftExpression, Parse(lexer));
        		}
        		else
        			leftExpression = Parse(lexer);
        		token = lexer.next();
        	}
        	else if( token.getOperatorType() == Type.CLOSEPAREN)
        	{
        		System.out.println("In Step 2: )");
        		// Return result if inside a "("
        		if(stack > 0)
        		{
            		stack--;
            		return leftExpression;
        		}
        		operator = null;
        		token = lexer.next();
        	}

        	if(token == null) return leftExpression;
            
            // STEP 1: Read # or LPAREN
        	// If #, make a new leaf expression for it.
        	//  Then we need to check the following symbol for an optional Unit.
        	//  Problem is, I don't know how to keep track of the leaf expression since
        	//  I can only store it to leftExpression if there's an operator.
        	// If "(", increase the stack, add the ( to the expression, and self-call.
            if( token.isNumber())
            {
        		System.out.println("In Step 1: Number");
            	tempExpression = new Expression(token);
               	// If we're inside () [stack > 0] it's safe to return the leaf
               	//  without exiting the rest of the parse tree.
               	if( stack > 0)
               	{
               		stack--;
               		return tempExpression;
               	}

       			// Otherwise, add the number to the expression and continue.
       			if( operator != null)
            	{
            		if(leftExpression != null)
            		{
            			leftExpression = new Expression(operator, leftExpression, tempExpression);
            		}
            		else
            			leftExpression = tempExpression; // This SHOULDN'T happen... but just in case
                	operator = null;
            	}
       			token = lexer.next();
        		System.out.println("In Step 1: Number (further down)");
        		if( token != null) System.out.println("Still not done.");
            }
            else if(token.getOperatorType() == Type.OPENPAREN)
            {
        		System.out.println("In Step 1: (");
            	stack++;
            	leftExpression = new Expression(token, leftExpression, Parse(lexer));
                token = lexer.next();
            }
        };
        // For when the loop ends (i.e. last token has been parsed)
		System.out.println("Out of Main loop");
        return leftExpression;
    }

    /* Applies the operator *+-/ to two Values
     * Any other operator is ignored and a null value is returned
     * (TODO: Encapsulate in error handling in case it tries to add null to something.
     * In the meantime, please don't break it. >_>)
     */
    public Value apply(Token operator, Value leftOperand, Value rightOperand) {
    	 System.out.println("In apply()");
        Type operatorType = operator.getOperatorType();
        ValueType leftType = leftOperand.type;
        ValueType rightType = rightOperand.type;
        Double leftValue = leftOperand.value;
        Double rightValue = rightOperand.value;

        switch (operatorType) {
        
            case PLUS:
                if (leftType == ValueType.SCALAR)
                {	// Take the other value's type
                    return(new Value(leftValue + rightValue, rightType));
                }
                else if (leftType == ValueType.INCHES)
                {	// Convert the right value to inches if necessary
                	if(rightType == ValueType.POINTS)
                	{
                		return(new Value(leftValue + rightValue*PT_PER_IN, leftType));
                	}
                	else
                		return(new Value(leftValue + rightValue, leftType));
                }
                else if (leftType == ValueType.POINTS)
                {	// Convert the right value to points if necessary
                	if(rightType == ValueType.INCHES)
                	{
                		return(new Value(leftValue + rightValue/PT_PER_IN, leftType));
                	}
                	else
                		return(new Value(leftValue + rightValue, leftType));
                }
            case MINUS:
                if (leftType == ValueType.SCALAR)
                {	// Take the other value's type
                    return(new Value(leftValue - rightValue, rightType));
                }
                else if (leftType == ValueType.INCHES)
                {	// Convert the right value to inches if necessary
                	if(rightType == ValueType.POINTS)
                	{
                		return(new Value(leftValue - rightValue*PT_PER_IN, leftType));
                	}
                	else
                		return(new Value(leftValue - rightValue, leftType));
                }
                else if (leftType == ValueType.POINTS)
                {	// Convert the right value to points if necessary
                	if(rightType == ValueType.INCHES)
                	{
                		return(new Value(leftValue - rightValue/PT_PER_IN, leftType));
                	}
                	else
                		return(new Value(leftValue - rightValue, leftType));
                }
            case MULTIPLY:
                if (leftType == ValueType.SCALAR) {
                    return(new Value(leftValue*rightValue, rightType));
                }
                else if (rightType == ValueType.SCALAR){
                    return(new Value(leftValue*rightValue, leftType));
                }
                else if (leftType == rightType) {
                    return(new Value(leftValue*rightValue, leftType));
                }
                else if (leftType == ValueType.INCHES && rightType == ValueType.POINTS ||
                		 leftType == ValueType.POINTS && rightType == ValueType.INCHES)
                {
                    return(new Value(leftValue*rightValue*PT_PER_IN, ValueType.POINTS));
                }
                else {
                    return(new Value(leftValue*rightValue, ValueType.SCALAR));
                }
            case DIVIDE:
            	if (rightValue == 0) return null;
                if (leftType == ValueType.SCALAR) {
                    return(new Value(leftValue/rightValue, rightType));
                }
                else if (rightType == ValueType.SCALAR){
                    return(new Value(leftValue/rightValue, leftType));
                }
                else {
                    return(new Value(leftValue/rightValue, ValueType.SCALAR));
                }
            default:
            	return null;
        }
    }

    // Main function called for a Parser instance
	public Value evaluate(String expression) {
		System.out.println("In evaluate()");
        Lexer lexer = new Lexer(expression);
        Expression parsed = Parse(lexer); // Parses the token stream (lexer) -- NOT a constructor call!
        return evaluateIter(parsed);
	}

	// Evaluates the expression recursively and returns a Value
    public Value evaluateIter(Expression parsed) {
    	if (parsed.isLeaf()) {
    		System.out.println("In evaluateIter() - Leaf");
            Token token = parsed.leaf;
    		System.out.println("Token value " + token.getTokenValue());
    		System.out.println("Token type " + token.getTokenType());
            return(new Value(token.getTokenValue(), token.getTokenType()));
        }
        else {
            Token operator = parsed.operator;
            Expression leftExpression = parsed.leftExpression;
            Expression rightExpression = parsed.rightExpression;
            return apply(operator, evaluateIter(leftExpression), evaluateIter(rightExpression));
            // Note that apply() can return null if (operator) is not +-*/
            }
        }
    }